import pandas as pd
import os
from datetime import datetime
from pyangus.exceptions.rpa_exception import AngusRpaException
from functools import wraps


class AngusRPA:
    """
    Decorator para RPA
    ex: @AngusRPA(collection_name="teste")
        collection_name: str
            Nome do Conjunto de Dados cadastrado no Portal
    """
    def __init__(self, collection_name, **kwargs):
        path = kwargs.get("path")
        path_default = 'teste50/'
        self.__path = path_default if path is None else path
        if os.path.exists(self.__path) is False:
            os.mkdir(self.__path)
        self._collection_name = collection_name

    def __save_dataset_csv(self, pandas_dataset):
        if type(pandas_dataset) != pd.DataFrame:
            raise AngusRpaException("O Retorno da Função não é do tipo Pandas DataFrame")
        pandas_dataset.to_csv(self.__path + self._collection_name + "_" + str(datetime.utcnow()) + ".csv", sep=";")

    def __call__(self, func):
        @wraps(func)
        def run(*args, **kwargs):
            pandas_dataset = func(*args, **kwargs)
            self.__save_dataset_csv(pandas_dataset)
            return pandas_dataset
        return run
