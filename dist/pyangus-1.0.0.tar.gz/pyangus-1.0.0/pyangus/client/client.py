import requests
import pandas as pd
from pyangus.exceptions.client_exception import AngusClientException
from pyangus.rpa.rpa import AngusRPA


def _request_angus(*args, **kwargs):
    response = requests.get(
        *args,
        **kwargs
    )
    response_body = response.json()
    if type(response_body) == dict and \
            len(list(response_body.keys())) == 1 and list(response_body.keys())[0] == 'Mensagem':
        raise AngusClientException(response_body['Mensagem'])
    return response_body


def _query_select_convert(filter_search):
    array_filter = filter_search.strip().split(" ")
    array_filter_conv = list()
    for index_filter in range(len(array_filter)):
        if array_filter[index_filter] in ["and", "or"]:
            if array_filter[index_filter] == "and":
                array_filter_conv.append("and")
            elif array_filter[index_filter] == "or":
                array_filter_conv.append("or")
        elif array_filter[index_filter] in [">", "<", ">=", "<=", "==", "!="]:
            if array_filter[index_filter] == ">":
                array_filter_conv.append((array_filter[index_filter-1] + "[gt]", array_filter[index_filter + 1]))
            elif array_filter[index_filter] == "<":
                array_filter_conv.append((array_filter[index_filter-1] + "[lt]", array_filter[index_filter + 1]))
            elif array_filter[index_filter] == ">=":
                array_filter_conv.append((array_filter[index_filter-1] + "[gte]", array_filter[index_filter + 1]))
            elif array_filter[index_filter] == "<=":
                array_filter_conv.append((array_filter[index_filter-1] + "[lte]", array_filter[index_filter + 1]))
            elif array_filter[index_filter] == "==":
                array_filter_conv.append((array_filter[index_filter-1] + "[eq]", array_filter[index_filter + 1]))
            elif array_filter[index_filter] == "!=":
                array_filter_conv.append((array_filter[index_filter-1] + "[neq]", array_filter[index_filter + 1]))

    return array_filter_conv


class AngusClient:
    """
    Client para Conexão no Angus Data Lake
    """
    def __init__(self, token_collection):
        """
        Parameters
        ----------
        token_collection: str
            Token de Associação do Conjunto de Dados
        """
        self._host = 'https://dados.noctua.sds.pe.gov.br/api/'
        self._token = token_collection

    def query(self, filter_search="", offset=None, limit=None):
        """
        Parameters
        ----------
        filter_search: str
            Filtro da consulta no Portal
        offset: int
            Offset da consulta no Portal
        limit:
            Limit da consulta no Portal

        Returns
        -------
        pandas.DataFrame
            Pandas DataFrame da consulta do conjunto de dados no Portal

        Raises
        ------
        AngusClientException
            Caso de acontecer algum erro de conexão com o Portal
        """
        headers = dict()
        params = dict()
        response_body = list()

        if offset is not None:
            headers["offset"] = offset
        if limit is not None:
            headers["limit"] = limit

        if len(str(filter_search)) > 0:
            array_filter = _query_select_convert(filter_search)
            for search in array_filter:
                if type(search) == tuple:
                    params[search[0]] = search[1]
                elif type(search) == str:
                    if search == 'and':
                        continue
                    elif search == 'or':
                        response_body += _request_angus(
                            url=self._host + "buscar",
                            params=params,
                            headers={"Authorization": self._token, "offset": "0", "limit": "10"}
                        )
                        params.clear()

            if len(params) > 0:
                response_body += _request_angus(
                    url=self._host + "buscar",
                    params=params,
                    headers={"Authorization": self._token, "offset": "0", "limit": "10"}
                )
        else:
            response_body += _request_angus(
                url=self._host + "buscar",
                headers={"Authorization": self._token, "offset": "0", "limit": "10"}
            )

        return pd.DataFrame(response_body)

    def info(self):
        """
        Returns
        -------
        pandas.DataFrame
            Pandas DataFrame das info do conjunto de dados

        Raises
        ------
        AngusClientException
            Caso de acontecer algum erro de conexão com o Portal
        """
        response_body = _request_angus(
            url=self._host + "info",
            headers={"Authorization": self._token}
        )
        return pd.DataFrame.from_dict(response_body, orient='index')

    def consulta_registros(self, id_conjunto):
        """
        Parameters
        ----------
        id_conjunto: str
            Id do conjunto de dados

        Returns
        -------
        pandas.DataFrame
            Pandas DataFrame da consulta de registros do conjunto de dados

        Raises
        ------
        AngusClientException
            Caso de acontecer algum erro de conexão com o Portal
        """
        response_body = _request_angus(
            url=self._host + "consulta_registros",
            params={"id": id_conjunto}
        )
        return pd.DataFrame.from_dict(response_body, orient='index')
